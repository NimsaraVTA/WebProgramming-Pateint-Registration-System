-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2021 at 08:40 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prweb`
--

-- --------------------------------------------------------

--
-- Table structure for table `breast_patient`
--

CREATE TABLE `breast_patient` (
  `Hospital` varchar(50) NOT NULL,
  `File` varchar(50) NOT NULL,
  `Reg` date NOT NULL,
  `Consult` varchar(50) NOT NULL,
  `Full` varchar(50) NOT NULL,
  `Age` int(3) NOT NULL,
  `Birth` date NOT NULL,
  `Sex` varchar(6) NOT NULL,
  `NIC` varchar(20) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Tel` int(10) NOT NULL,
  `Occupation` varchar(50) NOT NULL,
  `Marital` varchar(20) NOT NULL,
  `Member` varchar(10) NOT NULL,
  `Rela` varchar(50) NOT NULL,
  `Site` varchar(50) NOT NULL,
  `Ref` varchar(50) NOT NULL,
  `Topo` varchar(50) NOT NULL,
  `Histo` varchar(50) NOT NULL,
  `Icdo` varchar(10) NOT NULL,
  `Diag` date NOT NULL,
  `Tnm` varchar(50) NOT NULL,
  `Site2` varchar(50) NOT NULL,
  `S1` varchar(50) NOT NULL,
  `S2` varchar(50) NOT NULL,
  `S3` varchar(50) NOT NULL,
  `Mul` varchar(50) NOT NULL,
  `Rec` varchar(50) NOT NULL,
  `Rdate` date NOT NULL,
  `Treat` varchar(50) NOT NULL,
  `Dlast` date NOT NULL,
  `Remark` varchar(100) NOT NULL,
  `Refto` varchar(50) NOT NULL,
  `Slast` varchar(50) NOT NULL,
  `Nlast` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `breast_patient`
--

INSERT INTO `breast_patient` (`Hospital`, `File`, `Reg`, `Consult`, `Full`, `Age`, `Birth`, `Sex`, `NIC`, `Address`, `Tel`, `Occupation`, `Marital`, `Member`, `Rela`, `Site`, `Ref`, `Topo`, `Histo`, `Icdo`, `Diag`, `Tnm`, `Site2`, `S1`, `S2`, `S3`, `Mul`, `Rec`, `Rdate`, `Treat`, `Dlast`, `Remark`, `Refto`, `Slast`, `Nlast`) VALUES
('Kurunegala', '1212', '0000-00-00', 'Mr. Danuka', 'Dilini Ishara', 22, '0000-00-00', 'Female', '1213141V', '', 0, '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', '', ''),
('Kueunegala', '1215', '2021-09-25', 'Mr. Danuka', 'Upeksha Madhumali', 27, '2021-09-25', 'Female', '8867245V', 'VTA  Saragama', 0, 'Student', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `name` varchar(30) DEFAULT NULL,
  `mail` varchar(30) DEFAULT NULL,
  `teleno` int(10) DEFAULT NULL,
  `msg` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`name`, `mail`, `teleno`, `msg`) VALUES
('Thathsarani Nimsara (Developer', '', 0, 'Thank you so much for your kind comment. It gives me strength.\r\n(Web developer - Diploma Student in ICT at Vocational Training Authority of Sri Lanka)');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_contact`
--

CREATE TABLE `doctor_contact` (
  `d_name` varchar(20) NOT NULL,
  `d_no` varchar(10) NOT NULL,
  `d_details` varchar(100) NOT NULL,
  `is_deleted` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor_contact`
--

INSERT INTO `doctor_contact` (`d_name`, `d_no`, `d_details`, `is_deleted`) VALUES
('Mr. Danuka', 'xxxxxxxxxx', 'Specialist of gynecology', 0),
('Mrs. Imali', 'xxxxxxxxxx', 'Specialist for surgeon', 0),
('Mr. Dulan', 'xxxxxxxxxx', 'Specialist for surgeon', 0),
('Dr. Amali', '0112231562', 'Specialist for surgeon', 0),
('Dr. Samanthika', 'xxxxxxxxxx', 'Specialist for surgeon', 0),
('Dr. Anushka', 'xxxxxxxxxx', 'Specialist for surgeon', 0),
('Dr. Saman', 'xxxxxxxxxx', 'Specialist of gynecology', 0),
('Dr. Anula', 'xxxxxxxxxx', 'Specialist of gynecology', 0),
('Dr. Wimal', 'xxxxxxxxxx', 'Specialist of gynecology', 0),
('Dr. Kamal', 'xxxxxxxxxx', 'Specialist of gynecology', 0),
('Dr. Rameshwaran', 'xxxxxxxxxx', 'Specialist of gynecology', 0),
('Dr. Savi', '0715706965', 'No details', 0),
('dr. Viraj', '0715706965', 'No details', 0),
('Dr. Thath', 'xxxxxxxxxx', 'No details', 0),
('Mr. Thath', 'xxxxxxxxxx', 'No Details', 0);

-- --------------------------------------------------------

--
-- Table structure for table `onco_patient`
--

CREATE TABLE `onco_patient` (
  `Hospital` varchar(50) NOT NULL,
  `File` varchar(50) NOT NULL,
  `Reg` date NOT NULL,
  `Consult` varchar(50) NOT NULL,
  `Full` varchar(50) NOT NULL,
  `Age` int(3) NOT NULL,
  `Birth` date NOT NULL,
  `Sex` varchar(6) NOT NULL,
  `NIC` varchar(20) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Tel` int(10) NOT NULL,
  `Occupation` varchar(50) NOT NULL,
  `Marital` varchar(20) NOT NULL,
  `Member` varchar(10) NOT NULL,
  `Rela` varchar(50) NOT NULL,
  `Site` varchar(50) NOT NULL,
  `Ref` varchar(50) NOT NULL,
  `Topo` varchar(50) NOT NULL,
  `Histo` varchar(50) NOT NULL,
  `Icdo` varchar(10) NOT NULL,
  `Diag` date NOT NULL,
  `Tnm` varchar(50) NOT NULL,
  `Site2` varchar(50) NOT NULL,
  `S1` varchar(50) NOT NULL,
  `S2` varchar(50) NOT NULL,
  `S3` varchar(50) NOT NULL,
  `Mul` varchar(50) NOT NULL,
  `Rec` varchar(50) NOT NULL,
  `Rdate` date NOT NULL,
  `Treat` varchar(50) NOT NULL,
  `Dlast` date NOT NULL,
  `Remark` varchar(100) NOT NULL,
  `Refto` varchar(50) NOT NULL,
  `Slast` varchar(50) NOT NULL,
  `Nlast` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `onco_patient`
--

INSERT INTO `onco_patient` (`Hospital`, `File`, `Reg`, `Consult`, `Full`, `Age`, `Birth`, `Sex`, `NIC`, `Address`, `Tel`, `Occupation`, `Marital`, `Member`, `Rela`, `Site`, `Ref`, `Topo`, `Histo`, `Icdo`, `Diag`, `Tnm`, `Site2`, `S1`, `S2`, `S3`, `Mul`, `Rec`, `Rdate`, `Treat`, `Dlast`, `Remark`, `Refto`, `Slast`, `Nlast`) VALUES
('Kurunegala', '1212', '0000-00-00', 'Mr. Danuka', 'Dilini Ishara', 22, '0000-00-00', 'Female', '1213141V', '', 0, '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', '', ''),
('Kurunegala', '1213', '0000-00-00', 'Mrs. Thathsarani', 'Anupama Weerasekera', 23, '0000-00-00', 'Female', '987261315V', '', 0, 'Student', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', '', ''),
('Kueunegala', '1215', '2021-09-25', 'Mr. Danuka', 'Upeksha Madhumali', 27, '2021-09-25', 'Female', '8867245V', 'VTA  Saragama', 0, 'Student', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', '', ''),
('Colombo', '1216', '2021-09-18', 'Mrs. Thathsarani', 'Anupama Anjalee', 22, '2021-09-25', 'Female', '88776631V', '', 0, '', '', '', '', '', '', 'www', '', '', '0000-00-00', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `os_patient`
--

CREATE TABLE `os_patient` (
  `Hospital` varchar(50) NOT NULL,
  `File` varchar(50) NOT NULL,
  `Reg` date NOT NULL,
  `Consult` varchar(50) NOT NULL,
  `Full` varchar(50) NOT NULL,
  `Age` int(3) NOT NULL,
  `Birth` date NOT NULL,
  `Sex` varchar(6) NOT NULL,
  `NIC` varchar(20) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Tel` int(10) NOT NULL,
  `Occupation` varchar(50) NOT NULL,
  `Marital` varchar(20) NOT NULL,
  `Member` varchar(10) NOT NULL,
  `Rela` varchar(50) NOT NULL,
  `Site` varchar(50) NOT NULL,
  `Ref` varchar(50) NOT NULL,
  `Topo` varchar(50) NOT NULL,
  `Histo` varchar(50) NOT NULL,
  `Icdo` varchar(10) NOT NULL,
  `Diag` date NOT NULL,
  `Tnm` varchar(50) NOT NULL,
  `Site2` varchar(50) NOT NULL,
  `S1` varchar(50) NOT NULL,
  `S2` varchar(50) NOT NULL,
  `S3` varchar(50) NOT NULL,
  `Mul` varchar(50) NOT NULL,
  `Rec` varchar(50) NOT NULL,
  `Rdate` date NOT NULL,
  `Treat` varchar(50) NOT NULL,
  `Dlast` date NOT NULL,
  `Remark` varchar(100) NOT NULL,
  `Refto` varchar(50) NOT NULL,
  `Slast` varchar(50) NOT NULL,
  `Nlast` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `os_patient`
--

INSERT INTO `os_patient` (`Hospital`, `File`, `Reg`, `Consult`, `Full`, `Age`, `Birth`, `Sex`, `NIC`, `Address`, `Tel`, `Occupation`, `Marital`, `Member`, `Rela`, `Site`, `Ref`, `Topo`, `Histo`, `Icdo`, `Diag`, `Tnm`, `Site2`, `S1`, `S2`, `S3`, `Mul`, `Rec`, `Rdate`, `Treat`, `Dlast`, `Remark`, `Refto`, `Slast`, `Nlast`) VALUES
('Kurunegala', '1213', '0000-00-00', 'Mrs. Thathsarani', 'Anupama Weerasekera', 23, '0000-00-00', 'Female', '987261315V', '', 0, 'Student', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', '', ''),
('Kurunegala', '1214', '2021-09-04', 'Mrs. Sanduni', 'Danuka Heshan Gunarathne', 24, '0000-00-00', 'Male', '99887766V', '', 0, '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '0000-00-00', '', '0000-00-00', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `clinic` varchar(20) NOT NULL,
  `last_login` datetime(6) NOT NULL,
  `is_deleted` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `clinic`, `last_login`, `is_deleted`) VALUES
('Anupama', '12345', 'Onco', '0000-00-00 00:00:00.000000', 0),
('Awanthi', '123#', 'Onco Surgeory', '0000-00-00 00:00:00.000000', 0),
('Ayodya', '123', 'Breast', '0000-00-00 00:00:00.000000', 0),
('Danuka', '234', 'Breast', '2021-09-09 01:32:09.000000', 0),
('Hansamali', '123', 'Breast', '0000-00-00 00:00:00.000000', 0),
('Hasitha', '123', 'Onco Surgeory', '2021-09-10 00:24:40.000000', 0),
('Imali', '123', 'Onco Surgeory', '2021-09-02 17:32:53.000000', 0),
('Kavindi', '123', 'Breast', '0000-00-00 00:00:00.000000', 0),
('Madhumali', '123', 'Onco Surgeory', '0000-00-00 00:00:00.000000', 0),
('Osindu', '123', 'Breast', '0000-00-00 00:00:00.000000', 0),
('piyumi', '123', 'Onco', '2021-09-10 21:17:24.000000', 0),
('Piyumi', '1234', 'Onco', '2021-09-04 07:08:53.000000', 0),
('Pradeep', '123', 'Onco Surgeory', '2021-08-30 21:32:46.000000', 0),
('Saroja', '123', 'Onco', '2021-09-04 06:51:16.000000', 0),
('Tharuka', '123', 'Onco Surgeory', '0000-00-00 00:00:00.000000', 0),
('Thath', '123', 'Onco', '2021-09-03 20:31:06.000000', 0),
('Wihan', '123', 'Onco Surgeory', '0000-00-00 00:00:00.000000', 0),
('Windya', '123', 'Onco Surgeory', '0000-00-00 00:00:00.000000', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ward_contact`
--

CREATE TABLE `ward_contact` (
  `w_name` varchar(20) NOT NULL,
  `w_no` varchar(10) NOT NULL,
  `w_details` varchar(100) NOT NULL,
  `is_deleted` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ward_contact`
--

INSERT INTO `ward_contact` (`w_name`, `w_no`, `w_details`, `is_deleted`) VALUES
('Onco', '0773839268', 'Onco ward - Teaching Hospital, Kurunegala', 0),
('Onco Surgeory', '0773839268', 'onco surgeory ward - Teaching Hospital, Kurunegala', 0),
('Corona', '0112222222', 'Corona ward 20', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `breast_patient`
--
ALTER TABLE `breast_patient`
  ADD PRIMARY KEY (`File`);

--
-- Indexes for table `onco_patient`
--
ALTER TABLE `onco_patient`
  ADD PRIMARY KEY (`File`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`,`password`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
